#pragma once
#include <omp.h>


void OMPReductionSum(float* data, float* out, int size);