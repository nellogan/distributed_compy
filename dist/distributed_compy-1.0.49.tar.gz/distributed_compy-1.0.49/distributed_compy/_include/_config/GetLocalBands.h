#pragma once
#include <stdlib.h>
#include <string.h>
#include "GetGPUBands.h"

float* GetLocalBands(float* total_local_band, int* num_procs);