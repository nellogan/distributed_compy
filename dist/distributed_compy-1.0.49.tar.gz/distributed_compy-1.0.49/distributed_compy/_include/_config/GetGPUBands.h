#pragma once
#include <stdlib.h>

int GetNumGPUs();

float* GetGPUBands(int n_devices);