#pragma once
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "GetGPUBands.h"

void ConfigureLocal(const char *local_bands_file_name, const char *total_local_band_file_name);
