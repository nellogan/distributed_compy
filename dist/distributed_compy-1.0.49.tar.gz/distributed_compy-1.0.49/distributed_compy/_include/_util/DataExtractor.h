#pragma once
#include <stdio.h>
#include <stdlib.h>

float* DataExtractor(const char* data_file_name, long num_elements);