#pragma once
#include <stdio.h>

long GetFileLen(const char* data_file_name);