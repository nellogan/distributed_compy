#pragma once

void NaiveSum(float* data, float* out, int size);